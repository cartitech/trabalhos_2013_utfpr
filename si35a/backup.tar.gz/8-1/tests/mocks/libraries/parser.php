<?php

class Mock_Libraries_Parser extends CI_Parser {}