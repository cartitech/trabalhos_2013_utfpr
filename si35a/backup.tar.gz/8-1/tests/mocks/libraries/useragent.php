<?php

class Mock_Libraries_UserAgent extends CI_User_agent {}