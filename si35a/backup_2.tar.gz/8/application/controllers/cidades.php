<?php

class Cidades extends CI_Controller {

    public function __construct () {
        parent::__construct();
        $this->load->model("cidades_model");
        $this->load->helper("form");
    }

    public function show ($page = NULL) {
        $this->load->view("cidades/list", array(
            "cidades" => $this->cidades_model->get_cidades(
                $this->input->get("nome"))
        ));
    }

}
