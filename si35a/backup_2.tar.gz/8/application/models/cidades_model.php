<?php

class Cidades_model extends CI_Model {
    public function __construct () {
        $this->load->database();
    }

    public function get_cidades ($nome = NULL) {
        $query = $this->db->order_by("nome");
        if ( ! is_null($nome)) {
            $query->like("nome", "{$nome}", "after");
        }
        return $query->get("cidades")->result_array();
    }
}
