<!doctype html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8"0>
        <title>Listando cidades</title>
    </head>
    <body>
        <h1>Listando cidades</h1>
        <?php echo form_open("cidades/show", array("method" => "GET")) ?>
            <p>
                <label for="name">Nome: </label><input type="text" name="nome" id="nome" value="" />
                <input type="submit" value="Buscar &rarr;" />
            </p>
        </form>
        <ul>
            <?php foreach ($cidades as $cidade): ?>
                <li><?php echo $cidade["nome"] ?></li>
            <?php endforeach ?>
        </ul>
        <script type="text/javascript">
            var get_nome = window.location.search.split("nome=");
            if (get_nome.length > 1) {
                document.querySelector("input").value = get_nome[1].split("&")[0];
            }
        </script>
    </body>
</html>

